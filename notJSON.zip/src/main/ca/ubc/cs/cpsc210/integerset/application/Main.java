package ca.ubc.cs.cpsc210.integerset.application;

import ca.ubc.cs.cpsc210.integerset.util.IntegerSet;

// simple application illustrating use of the IntegerSet class
public class Main {
    public static void main(String[] args) {
        IntegerSet setA = new IntegerSet();
        IntegerSet setB = new IntegerSet();

// insert some elements to setA and setB (be sure to do this in your code!)

        IntegerSet intersectAB = setA.intersection(setB);

    }
}
